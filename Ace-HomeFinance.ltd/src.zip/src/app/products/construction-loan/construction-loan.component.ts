import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-construction-loan',
  templateUrl: './construction-loan.component.html',
  styleUrls: ['./construction-loan.component.css']
})
export class ConstructionLoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
