import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rural-home-loan',
  templateUrl: './rural-home-loan.component.html',
  styleUrls: ['./rural-home-loan.component.css']
})
export class RuralHomeLoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
