import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-renovation-home-loan',
  templateUrl: './renovation-home-loan.component.html',
  styleUrls: ['./renovation-home-loan.component.css']
})
export class RenovationHomeLoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
