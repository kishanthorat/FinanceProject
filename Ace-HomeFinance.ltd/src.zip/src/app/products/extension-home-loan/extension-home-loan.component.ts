import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-extension-home-loan',
  templateUrl: './extension-home-loan.component.html',
  styleUrls: ['./extension-home-loan.component.css']
})
export class ExtensionHomeLoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
