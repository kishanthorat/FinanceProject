import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plot-loan',
  templateUrl: './plot-loan.component.html',
  styleUrls: ['./plot-loan.component.css']
})
export class PlotLoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
