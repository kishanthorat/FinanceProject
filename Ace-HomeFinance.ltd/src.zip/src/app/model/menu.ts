export class Menu {
    public static menu: Array<any> = [
        {
    
      operational:[
        {path: "operational/oedash", title: "DASHBORD", icon: "pe-7s-graph", class: "" },
        {path: "operational/oeenquiry", title: "VIEW ENQUIERY", icon: "pe-7s-graph", class: "" },
        {path: "operational/appform", title: "Loan Application Form", icon: "pe-7s-graph", class: "" },
      ],
      loanOfficer:[
        {path:"loanOfficer/loenquiry", title:"Enquiry", icon: "pe-7s-graph", class: ""  },
        {path:"loanOfficer/customers", title:"Customerlist", icon: "pe-7s-graph", class: ""  },
        {path:"loanOfficer/loanapp", title:"Fill Application Form", icon: "pe-7s-graph", class: ""  }

      ]
     
 } ];
}
