import { Enquiry } from './enquiry';

describe('Enquiry', () => {
  it('should create an instance', () => {
    expect(new Enquiry()).toBeTruthy();
  });
});
