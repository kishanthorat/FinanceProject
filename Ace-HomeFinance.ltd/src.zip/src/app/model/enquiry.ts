export class Enquiry {
    enquiryId:number;
    enquiryName :string;
    age:number;
    email:string;
    mobileNo:bigint;
    pancardNo:string;
}
