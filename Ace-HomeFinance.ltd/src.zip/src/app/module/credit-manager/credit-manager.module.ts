import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreditManagerRoutingModule } from './credit-manager-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CreditManagerRoutingModule
  ]
})
export class CreditManagerModule { }
