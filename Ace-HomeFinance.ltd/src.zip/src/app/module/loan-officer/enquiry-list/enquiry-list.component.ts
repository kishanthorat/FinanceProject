import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enquiry-list',
  templateUrl: './enquiry-list.component.html',
  styleUrls: ['./enquiry-list.component.css']
})
export class EnquiryListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
