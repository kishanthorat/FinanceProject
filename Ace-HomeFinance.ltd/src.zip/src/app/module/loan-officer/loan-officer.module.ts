import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoanOfficerRoutingModule } from './loan-officer-routing.module';
import { LoanApplicationComponent } from './loan-application/loan-application.component';
import { EnquiryListComponent } from './enquiry-list/enquiry-list.component';
import { CustomerlistComponent } from './customerlist/customerlist.component';


@NgModule({
  declarations: [
    LoanApplicationComponent,
    EnquiryListComponent,
    CustomerlistComponent
  ],
  imports: [
    CommonModule,
    LoanOfficerRoutingModule
  ]
})
export class LoanOfficerModule { }
