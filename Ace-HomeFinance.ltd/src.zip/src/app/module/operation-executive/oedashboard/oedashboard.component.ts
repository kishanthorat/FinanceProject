import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oedashboard',
  templateUrl: './oedashboard.component.html',
  styleUrls: ['./oedashboard.component.css']
})
export class OedashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
