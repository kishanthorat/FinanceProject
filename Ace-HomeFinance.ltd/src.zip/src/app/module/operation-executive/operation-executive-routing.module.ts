import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicationFormComponent } from './application-form/application-form.component';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { OedashboardComponent } from './oedashboard/oedashboard.component';

const operationalRoutes: Routes = [
  {
    path:'oedash' , component: OedashboardComponent
  },
  {
    path:'oeenquiry', component:EnquiryComponent
  },
  {
    path:'appform' , component:ApplicationFormComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(operationalRoutes)],
  exports: [RouterModule]
})
export class OperationExecutiveRoutingModule { }
