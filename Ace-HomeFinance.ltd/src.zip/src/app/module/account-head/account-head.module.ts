import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountHeadRoutingModule } from './account-head-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AccountHeadRoutingModule
  ]
})
export class AccountHeadModule { }
