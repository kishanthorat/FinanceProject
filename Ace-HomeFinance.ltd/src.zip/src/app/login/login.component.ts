import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor(private fb : FormBuilder, private router: Router) { }
  loginForm: FormGroup;
  ngOnInit(): void {
    this.loginForm=this.fb.group({
      username:[''],
      password:['']
    })
  }

  logOn(){

    if (this.loginForm.get('username').value=="oe" && this.loginForm.get('password').value=="oe"){
      console.log('in re')
      sessionStorage.setItem('role', 'operational');
      this.router.navigateByUrl("role/operational/oedash");
    }
    if (this.loginForm.get('username').value=="lo" && this.loginForm.get('password').value=="lo"){
      sessionStorage.setItem('role', 'loanOfficer');
      this.router.navigateByUrl("role/loanOfficer/loenquiry");
    }
    
}
}
