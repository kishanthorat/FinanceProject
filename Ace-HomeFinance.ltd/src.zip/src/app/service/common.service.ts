import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Enquiry } from 'app/model/enquiry';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http : HttpClient) { }
  url:string="http://localhost:8888/enquiry";
  addEnquiry(enquiry :Enquiry){
    return this.http.post<Enquiry>(this.url, enquiry);



  }
}
